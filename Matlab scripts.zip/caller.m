clear;
hyppighet=10;   %Time (in minutes) between each simulated measurement point
standardize=1;  %Standardize predictors (1=yes, 0=no)
display=0;      %Showing plots of simulated data and ANN training (1=yes, 0=no)
reps=10;        %Number of replications

rng('shuffle'); %Sets the random number generator based on the current time

%Simulation settings:
spred=[5,20];               %Liver-to-liver variation
noise_power=[0 10 30];      %Level of white gaussian noise (dBW) in the simulated measurement
drift_case=1:3;             %Three cases of drift added to simulated measurement (see lines 39-41)
%Input data settings:
N=[20, 100];                %Number of livers in the training and test set
w{1}=[1e2 1e4 1e6];         %Resistance and reactance at three frequencies as input
w{2}=10.^(1:1:7);           %Resistance and reactance at seven frequencies as input
w{3}=10.^(1:0.1:7);         %Resistance and reactance at 70 frequencies as input
%Neural network training settings
epochs=[250,500];           %Epochs for training of the LSTM network
l2=[0.1, 0.01, 0.001];      %Regularization value
nodes=[2 5 25];             %Hidden layer size
minibatchsize=[16,32];      %Minibatch size in training of the LSTM network

variables={'frekvens valg','spredning', 'l2', 'nodes','noise_power','drift','drift_direction',...
    'N', 'minibatchsize', 'acc FNN', 'acc LSTM', 'acc 2LSTM', 'fit FNN', 'fit LSTM', 'fit 2LSTM',};

maxit=length(w)*length(spred)*length(l2)*length(nodes)*length(noise_power)*length(drift_case)*...
   length(N)*length(minibatchsize)*reps; %Maximum number of iterations in calculation of progress

result=[];
%Loops for calling the machine learning and prediction for all selected
%cases and storing the results in the "result" variable
for rep=1:reps
    for w_i=1:length(w)
        for spred_i=1:length(spred)
            for l2_i=1:length(l2)
                for nodes_i=1:length(nodes)
                    for noise_power_i=1:length(noise_power)
                        for drift_case_i=1:length(drift_case)
                            if drift_case(drift_case_i)==1; drift_i=0; drift_direction_i=0; end     %No drift
                            if drift_case(drift_case_i)==2; drift_i=100; drift_direction_i=0; end   %Maximum drift of 100 Ohms/hour, both directions possible
                            if drift_case(drift_case_i)==3; drift_i=100; drift_direction_i=1; end   %Maximum drift of 100 Ohms/hour, only positive drift (impedance increase) possible
                            for N_i=1:length(N)
                                for minibatchsize_i=1:length(minibatchsize)
                                    for epochs_i=1:length(epochs)
                                         %Calling of the FNN, LSTM and
                                         %2LSTM functions in the following
                                         %three lines, aquiring their
                                         %regression errors in the acc_xxx
                                         %variables
                                         [acc_fnn, fit_fnn]=fnn_regression_fnc(hyppighet, w{w_i},spred(spred_i),l2(l2_i),nodes(nodes_i),noise_power(noise_power_i),drift_i,drift_direction_i,N(N_i),standardize,display);
                                         [acc_lstm,fit_lstm]=lstm_regression_fnc(epochs(epochs_i), hyppighet, w{w_i},spred(spred_i),l2(l2_i),nodes(nodes_i),minibatchsize(minibatchsize_i),noise_power(noise_power_i),drift_i,drift_direction_i,N(N_i),standardize,display);
                                         [acc_2lstm,fit_2lstm]=lstm_stacked_regression_fnc(epochs(epochs_i), hyppighet, w{w_i},spred(spred_i),l2(l2_i),nodes(nodes_i),minibatchsize(minibatchsize_i),noise_power(noise_power_i),drift_i,drift_direction_i,N(N_i),standardize,display);
                                         result_line=[rep w_i spred_i l2_i nodes_i noise_power_i drift_case_i N_i minibatchsize_i acc_fnn acc_lstm acc_2lstm fit_fnn fit_lstm fit_2lstm];
                                         result=[result; result_line]; %Storage of results
                                         disp(['Progress = ', num2str(size(result,1)./maxit*100), ' %'])
                                         %waitbar(size(result,1)./maxit)
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

save ('results.mat', 'result')
 