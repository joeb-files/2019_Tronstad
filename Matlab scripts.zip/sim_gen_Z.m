function Z=sim_gen_z(w,varighet,hyppighet,prosent_spredning)

j=sqrt(-1);

%Define cole parameters of two-dispersion model approximating the Gheorgiou et al data

    R0_1=200; Rinf_1=50; fc_1=2000; alpha_1=0.3; tau_1=1/fc_1; tau_1=0.005; tau_1=0.01; 
    R0_2=800; Rinf_2=50; fc_2=100e3; alpha_2=0.4; tau_2=1/fc_2; tau_2=1e-5; tau_2=5e-6; tau_2=3e-6; 
  
    %Adding random variance within given range (prosent spredning) to the cole parameters
    R0_1=R0_1+R0_1*(prosent_spredning/100)*randn(1);
    R0_2=R0_2+R0_2*(prosent_spredning/100)*randn(1);
    Rinf_1=Rinf_1+Rinf_1*(prosent_spredning/100)*randn(1);
    Rinf_2=Rinf_2+Rinf_2*(prosent_spredning/100)*randn(1);
    tau_1=tau_1+tau_1*(prosent_spredning/100)*randn(1);
    tau_2=tau_2+tau_2*(prosent_spredning/100)*randn(1);
    alpha_1=alpha_1+alpha_1*(prosent_spredning/100)*randn(1);
    alpha_2=alpha_2+alpha_2*(prosent_spredning/100)*randn(1);
    
    min_per_meas=hyppighet; %Define minutes per simulated measurement
    
    %Define rates of change in R0 of three following phases, approximating
    %the Gheorgiou et al data. Random variance is added according to prosent_spredning
    rate_R0_1_p1=2;
    rate_R0_1_p1=rate_R0_1_p1+rate_R0_1_p1*(prosent_spredning/100)*randn(1);
    rate_R0_2_p1=10;
    rate_R0_2_p1=rate_R0_2_p1+rate_R0_2_p1*(prosent_spredning/100)*randn(1);
    rate_R0_2_p2=15;
    rate_R0_2_p2=rate_R0_2_p2+rate_R0_2_p2*(prosent_spredning/100)*randn(1);
    rate_R0_2_p3=-0.5;
    rate_R0_2_p3=rate_R0_2_p3+rate_R0_2_p3*(prosent_spredning/100)*randn(1);
    
    %Development of cole parameters R0 and Tau during liver ischemia, approximated according
    %to the Gheorghiou et al data
for t=1:round(varighet/min_per_meas)
    min(t)=t*min_per_meas; %Time in minutes
    if t>1
    %R0_1 development during ischemia
    if min(t)<110 R0_1(t)=R0_1(t-1)+rate_R0_1_p1*min_per_meas; end
    if (min(t)>=110 & min(t)<170) R0_1(t)=R0_1(t-1)-((max(R0_1)-Rinf_1)/60)*min_per_meas; end 
    if min(t)>=170 R0_1(t)=Rinf_1; end
    if R0_1(t)<Rinf_1 R0_1(t)=Rinf_1; end
    %R0_2 development during ischemia
    if min(t)<70 R0_2(t)=R0_2(t-1)+rate_R0_2_p1*min_per_meas; end 
    if (min(t)>=70 & min(t)<120) R0_2(t)=R0_2(t-1); end
    if (min(t)>=120 & min(t)<170) R0_2(t)=R0_2(t-1)+rate_R0_2_p2*min_per_meas; end
    if min(t)>=170 R0_2(t)=R0_2(t-1)+rate_R0_2_p3*min_per_meas; end 
    if R0_2(t)<0 R0_2(t)=Rinf_2; end
    %Tau_2 development during ischemia
    if min(t)<50 tau_2(t)=tau_2(t-1)+7e-8*min_per_meas; end
    if (min(t)>=50 & min(t)<120) tau_2(t)=tau_2(t-1); end
    if (min(t)>=120 & min(t)<170) tau_2(t)=tau_2(t-1)+10e-8*min_per_meas; end
    if min(t)>=170 tau_2(t)=tau_2(t-1)-4.0e-9*min_per_meas; end
    %Tau_1 development during ischemia
    if min(t)<50 tau_1(t)=tau_1(t-1)+4e-4*min_per_meas; end
    if (min(t)>=50 & min(t)<120) tau_1(t)=tau_1(t-1); end 
    if (min(t)>=120 & min(t)<170) tau_1(t)=tau_1(t-1)+6e-4*min_per_meas; end
    if min(t)>=170 tau_1(t)=tau_1(t-1); end
    end
end

%Smoothing of curves for R0 and Tau
 R0_1=smoothdata(R0_1,'gaussian',60/min_per_meas);
 R0_2=smoothdata(R0_2,'gaussian',60/min_per_meas);
 tau_1=smoothdata(tau_1,'gaussian',60/min_per_meas);
 tau_2=smoothdata(tau_2,'gaussian',60/min_per_meas);
 
 %Calculation of impedance spectra over time
 for t=1:round(375/min_per_meas)
    Z1(t,:)=Rinf_1+(R0_1(t)-Rinf_1)./(1+j*w*tau_1(t)).^alpha_1;
    Z2(t,:)=Rinf_2+(R0_2(t)-Rinf_2)./(1+j*w*tau_2(t)).^alpha_2;
    Z(t,:)=Z1(t,:)+Z2(t,:);
 end