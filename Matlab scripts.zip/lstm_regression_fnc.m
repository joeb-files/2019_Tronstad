function [acc_test,acc_train] = sim_lstm_regression_fnc(epochs, hyppighet, w, spred, l2, nodes, minibatch_size, noise_power, drift, drift_direction, N, standardize, display_on)
drift_str=drift;
duration=375; %Duration of the simulated measurement during ischemia
cases=N;
for i=1:cases
Z{i}=sim_gen_Z(w,duration,hyppighet,spred); %Calling the simulation of measurements, returning impedance during ischemia for different livers in Z
end
tid=(0:size(Z{i},1)-1)*hyppighet/60; %Time in hours

maxlen=round(duration/hyppighet);    %Number of measurement points in each bioimpedance time series
for i=1:length(Z)
    X{i}=[real(Z{i}),-imag(Z{i})];   %Splitting the complex impedance into resistance and -reactance as predictors
    y{i}=tid;                        %Assigning time to y, the target variable for ischemic duration
    startlen=ceil(rand()*maxlen);    %Picking a random time point (between 1 and maxlen) when ischemia starts 
    X{i}=[repmat(X{i}(1,:),startlen,1); X{i}]; %Setting the pre-ischemic bioimpedance to baseline level
    y{i}=[zeros(startlen,1)',y{i}];            %Setting the pre-ischemic target to zero (no ischemia duration yet)
    X{i}(length(tid)+1:end,:)=[]; y{i}(length(tid)+1:end)=[]; %cutting the ends for equal lengths
    Xcon{i}=repmat(X{i}(1,:),length(tid),1);   %Creating predictors for control cases (no ischemia)
    ycon{i}=zeros(length(tid),1)';             %Creating targets for control cases (array of zero)
    
    rand_drift_slope=(rand()-0.5+0.5*drift_direction)*drift_str; %Random drift (Ohms/hour) for each recording
    drift=tid.*rand_drift_slope;                                 %Drift array over time
    for j=1:size(X{i},2)                            %Add noise and drift to the measurement
        noise=wgn(size(X{i},1),1,noise_power);      %Create white gaussian noise
        if noise_power>0 
            X{i}(:,j)=X{i}(:,j)+noise; %Add noise to measurement
            Xcon{i}(:,j)=Xcon{i}(:,j)+noise; 
        end
        X{i}(:,j)=X{i}(:,j)+drift'; %Add drift to measurement
        Xcon{i}(:,j)=Xcon{i}(:,j)+drift';
    end
    X{i}=X{i}'; Xcon{i}=Xcon{i}'; %Transpose
end

%Define LSTM network
numResponses = 1;
inputSize=size(X{1},1);
outputSize=nodes;
outputMode='sequence';
layers = [ ...
    sequenceInputLayer(inputSize)
    lstmLayer(outputSize,'OutputMode',outputMode)
    fullyConnectedLayer(numResponses)
    regressionLayer];

%Define LSTM network training
maxEpochs = epochs;
miniBatchSize = minibatch_size; 
shuffle = 'never';
if display_on==1 plots='training-progress'; else plots='none'; end

options = trainingOptions('adam', ...
    'MaxEpochs',maxEpochs, ...
    'MiniBatchSize',miniBatchSize, ...
    'Plots', plots,...
    'InitialLearnRate', 0.01,... 
    'LearnRateSchedule','piecewise',...
    'LearnRateDropFactor',0.99,... 
    'L2Regularization',l2,...
    'LearnRateDropPeriod',10,...
    'ExecutionEnvironment','cpu',...
    'Verbose',false,...
    'Shuffle', shuffle);


N=size(X,2);
r=randperm(N);  %Random permutation of ischemic livers
X_train=X(r(1:N/2)); X_test=X(r(N/2+1:end)); %Assign 50% of ischemic livers to training and test partitions
y_train=y(r(1:N/2)); y_test=y(r(N/2+1:end));

N=size(Xcon,2);
r=randperm(N);  %Random permutation of control livers
Xcon_train=Xcon(r(1:N/2)); Xcon_test=Xcon(r(N/2+1:end)); %Assign 50% of control livers to training and test partitions
ycon_train=ycon(r(1:N/2)); ycon_test=ycon(r(N/2+1:end));
X_train=[X_train,Xcon_train]; y_train=[y_train,ycon_train]; %Concatenate ischemic and control livers
X_test=[X_test,Xcon_test]; y_test=[y_test,ycon_test];


%Find mean and standard deviations from training data
for i=1:length(X_train)
    for j=1:size(X_train{1},1)
        m(i,j)=mean(X_train{i}(j,:));
        s(i,j)=std(X_train{i}(j,:));
    end
end
meanX_train=mean(m,1);
stdX_train=mean(s,1);

%Use mean and standard deviation from training data to standardize
%predictors in training and test partitions
if standardize==1
for i=1:length(X_train)
    for j=1:size(X_train{1},1)
        X_train{i}(j,:)=(X_train{i}(j,:)-meanX_train(j))/stdX_train(j);
    end
end
for i=1:length(X_test)
    for j=1:size(X_test{1},1)
        X_test{i}(j,:)=(X_test{i}(j,:)-meanX_train(j))/stdX_train(j);
    end
end
end

%Sort sequences according to length in case they differ, for improved training
numObservations = numel(X_train);
for i=1:numObservations
    sequence = X_train{i};
    sequenceLengths(i) = size(sequence,2);
end
[sequenceLengths,idx] = sort(sequenceLengths);
X_train = X_train(idx);
y_train = y_train(idx);
 
if display_on==1
figure(2)
clf
%Plot training and test data together, one subplot for each predictor
%The figure shows the standardized resistance (upper half of subplots) and
%reactance (lower half of subplots) vs time point (1-38), where training
%data is plotted in red and test data in blue lines
for i=1:length(w)*2
    subplot(length(w)*2,1,i)
    hold on
    for j=1:length(X_train)
        plot(X_train{j}(i,:),'red')
    end
    for j=1:length(X_test)
        plot(X_test{j}(i,:),'blue')
    end
    hold off
end
end
 
[net,trainInfo] = trainNetwork(X_train,y_train,layers,options); %Neural network is trained, model is stored in net
ypred = predict(net,X_test,'MiniBatchSize',1); %Predictions using the model on test data
yfit = predict(net,X_train); %Model fit on training data

if display_on==1
%Plotting of test data predictions vs target for all livers in the test set   
figure(4)
clf
hold on
for i=1:length(y_test)
    scatter(y_test{i},ypred{i})
end
hold off
title('Predicted vs target ischemic duration, LSTM model')
end
%Calculation of the prediction error for each test data liver
for i=1:length(y_test)
    rmse(i)=sqrt(mean(((y_test{i}-ypred{i}).^2)));
    rmse_fit(i)=sqrt(mean(((y_train{i}-yfit{i}).^2)));
end
%Using the mean prediction error over all test data livers as an overall prediction error
acc_test=mean(rmse);
acc_train=mean(rmse_fit);

